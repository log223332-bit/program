@echo off
cd /d "%~dp0"
start "" "KMSAutox64.exe"